﻿namespace P02._Worker_After
{
    using Contracts;

    class HighPerformer : IWorker
    {
        public void Work()
        {
            //work
        }
    }
}
