﻿namespace P02._DrawingShape_Before.Contracts
{
    public interface IShape
    {
    }
}
