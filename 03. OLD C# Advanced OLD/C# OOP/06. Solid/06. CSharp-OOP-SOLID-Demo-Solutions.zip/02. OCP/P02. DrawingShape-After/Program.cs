﻿using System;

namespace P02._DrawingShape_After
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
