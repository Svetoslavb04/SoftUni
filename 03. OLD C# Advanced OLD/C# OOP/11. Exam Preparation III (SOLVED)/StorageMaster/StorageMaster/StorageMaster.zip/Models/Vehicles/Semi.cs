﻿namespace StorageMaster.Models.Vehicles
{
    public class Semi : Vehicle
    {
        private const int InitialCapacity = 10;

        public Semi() : base(InitialCapacity)
        {
        }
    }
}
