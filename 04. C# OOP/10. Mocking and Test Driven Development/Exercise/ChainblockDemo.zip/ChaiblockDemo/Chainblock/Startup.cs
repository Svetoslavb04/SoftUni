﻿using System.Collections.Generic;

namespace Chainblock
{
    public class Startup
    {
        public static void Main(string[] args)
        {
            Dictionary<int, int> keyValuePairs = new Dictionary<int, int>();

            //keyValuePairs.Add(1, 1);
            //keyValuePairs.Add(1, 1);

            keyValuePairs[1] = 1;
            keyValuePairs[1] = 20;
        }
    }
}
